// config.js
const GAS_BASE_URL = "https://script.google.com/macros/s/AKfycby-6r7AHEqFeJNpM_vDL1vYd2q2-P13z71FyBfrgtbCzQTVIa-X3aczyc4-y2-6IsM0/exec"; // สำหรับวิเคราะห์ SEO
const PROXY_URL = "https://script.google.com/macros/s/AKfycbyosSmXzFu4osJvXkT4KQcs_MukFk8Q61BujWhxiRACrY1f-555zHONrXUOTRgp_1a1QA/exec"; // สำหรับ stream โดยเฉพาะ
